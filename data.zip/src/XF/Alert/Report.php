<?php

namespace XF\Alert;

use XF\Mvc\Entity\Entity;

class Report extends AbstractHandler {}